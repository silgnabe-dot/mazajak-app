مشروع Android Studio لتطبيق ابدأ الآن
=====================================
1. ثبّت Android Studio بإصدار حديث.
2. افتح هذا المجلد android-project (وليس مجلد web).
3. وافق على تنزيل Gradle وAndroid SDK إذا طلب البرنامج ذلك.
4. من القائمة Build اختر Build APK(s).
5. APK التجريبي يظهر في app/build/outputs/apk/debug/app-debug.apk.

المشروع يشغّل ملفات HTML المحلية داخل WebView، لذا الواجهة الأساسية لا تحتاج إنترنت. الروابط الخارجية مثل YouTube تفتح في المتصفح. لم يتم إرفاق APK جاهز لأن بناء APK يتطلب بيئة Android SDK/Gradle على جهاز بناء؛ المرفق هو مشروع قابل للبناء.
